import{dT as r}from"./card-04eb008a.js";function o(o){const s=r(o);return s.setHours(23,59,59,999),s}export{o as e};
